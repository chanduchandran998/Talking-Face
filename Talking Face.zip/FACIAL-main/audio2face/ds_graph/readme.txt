Please download the pre-trained DeepSpeech model v0.1.0 from Mozilla (hhttps://github.com/mozilla/DeepSpeech/releases/tag/v0.1.0) and place it in this folder
